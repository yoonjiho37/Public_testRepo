//
//  LionSchoolApp.swift
//  LionSchool
//
//  Created by Jongwook Park on 2023/06/30.
//

/*
 
 이 앱은 멋사학교의 학생들의 정보를 확인하기 위한 앱이다
 
 1 : 학년 목록이 나온다
 2 : 선택된 한학년의 학급들이 나온다
 3 : 학급의 학생들이 나온다
 4 : 학생의 세부정보가 나온다
 
 */

import SwiftUI

@main
struct LionSchoolApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
