//
//  GameView.swift
//  QuizQuiz
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

struct GameView: View {
    @State var gameIndex: Int = 0
    @State var collectCount: Int = 0
    
    // 전체 진행 문제 갯수와 맞춘 갯수만 알면 틀린 갯수 연산 프로퍼티로 만들 수 있다~!
    var wrongCount: Int {
        return gameIndex - collectCount
    }
    
    // 배열에서 몇번째 것 가져오기 매번 여기저기 코드에 섞으면 정신없다
    // 그래서 연산프로퍼티로 깔끔하게 퉁치고 가자!
    var gameData: GameData {
        return games[gameIndex]
    }
    
    @State var mixedAnswers: [String] = []
    
    var body: some View {
        List {
            if gameIndex < games.count {
                Section {
                    Text("\(gameData.question)")
                }
                Section {
                    // 무제의 보기 항목을 하나씩 보여주자
                    ForEach(mixedAnswers, id: \.self) { answer in
                        
                        // 정답일 때와 아닐 때의 버튼을 구분해서 다르게 처리하자
                        if gameData.answer == answer {
                            Button {
                                collectCount += 1
                                gameIndex += 1
                                readyNextGame()
                            } label: {
                                Text("\(answer)")
                            }
                            
                        } else {
                            
                            Button {
                                gameIndex += 1
                                readyNextGame()
                            } label: {
                                Text("\(answer)")
                            }
                            
                        }
                    }
                }
                Section {
                    Text("맞춘 문제 : \(collectCount)")
                    Text("틀린 문제 : \(wrongCount)")
                }
            } else {
                Section {
                    Text("게임 결과")
                        .font(.largeTitle)
                    Text("맞춘 문제 : \(collectCount)")
                    Text("틀린 문제 : \(wrongCount)")
                }
                Section {
                    Button {
                        games.shuffle()
                        gameIndex = 0
                        collectCount = 0
                        readyNextGame()
                    } label: {
                        Text("다시 시작")
                    }
                }
            }
        }
        .onAppear {
            games.shuffle()
            readyNextGame()
        }
    }
    
    func readyNextGame() {
        // State로 지정된 값이 하나라도 바뀌면
        // body가 새로 그려지려고 하기때문에
        // 아주 미세한 순간적인 문제로 gameIndex가
        // 실제 games 배열 밖의 내용을 가져와 쓰려할 때가 생긴다
        // 그런 일을 막으려고 이런 if문을 만들었다
        
        if gameIndex > -1 && gameIndex < games.count {
            // 정답과 오답을 묶어서 새로운 배열을 만들고 섞자!
            mixedAnswers = gameData.wrongAnswers + [gameData.answer]
            mixedAnswers.shuffle()
        }
    }
}

struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}
