//
//  ContentView.swift
//  QuizQuiz
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

struct ContentView: View {
    
    // 보틍 ContentView는 서브뷰들을 활용해서
    // 가장 단순한 코드 조합이 되는 것이 좋다
    // - 나중에 서브뷰 제대로 배우고 써보자!
    var body: some View {
        VStack {
            TitleView()
            
            Spacer()
            
            GameView()
            
            Spacer()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
