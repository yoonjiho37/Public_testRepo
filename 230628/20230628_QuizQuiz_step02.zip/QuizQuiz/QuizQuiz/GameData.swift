//
//  GameData.swift
//  QuizQuiz
//
//  Created by Jongwook Park on 2023/06/28.
//

import Foundation

struct GameData {
    var question: String
    var answer: String
    var wrongAnswers: [String]
}

var games: [GameData] = [
    GameData(question: "2018년 러시아 올림픽에 도입된 \"비디오 판독 시스템\" 이름은?",
             answer: "VAR",
             wrongAnswers: ["VCR", "VTR"]),
    GameData(question: "아리랑 가사에 등장하는 \"십리도 못 가서 발병 난다\" 중 \"십리(10리)\"는 몇 킬로미터에 해당 될까?",
             answer: "4km",
             wrongAnswers: ["1km", "10km"]),
    GameData(question: "우리나라 최초의 배달 음식은?",
             answer: "해장국",
             wrongAnswers: ["설렁탕", "짜장면"]),
    GameData(question: "지구에서 가장 큰 대륙은?",
             answer: "아프리카",
             wrongAnswers: ["유럽", "아시아", "북아메리카"]),
    GameData(question: "태양계에서 가장 가까운 행성은?",
             answer: "수성",
             wrongAnswers: ["금성", "지구", "화성"]),
    GameData(question: "사과의 색깔 중에서 없는 색은?",
             answer: "파란색",
             wrongAnswers: ["빨간색", "노란색", "초록색"]),
    GameData(question: "세계에서 가장 높은 산은?",
             answer: "에베레스트",
             wrongAnswers: ["히말라야", "쿨루", "파랑산"])
]

 
