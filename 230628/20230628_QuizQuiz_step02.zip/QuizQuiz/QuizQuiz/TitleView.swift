//
//  TitleView.swift
//  QuizQuiz
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

struct TitleView: View {
    var body: some View {
        Image("title")
            .resizable()
            .aspectRatio(contentMode: .fit)
    }
}

struct TitleView_Previews: PreviewProvider {
    static var previews: some View {
        TitleView()
    }
}
