//
//  ContentView.swift
//  RockPaperScissors
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

enum HandSelection {
    case rock
    case paper
    case scissors
}

struct ContentView: View {
    @State var resultText: String = ""
    
    var body: some View {
        VStack {
            Text("\(resultText)")
                .padding()
            HStack {
                Button {
                    showResult(selection: .scissors)
                } label: {
                    Text("✌️가위")
                }
                Spacer()
                Button {
                    showResult(selection: .rock)
                } label: {
                    Text("👊바위")
                }
                Spacer()
                Button {
                    showResult(selection: .paper)
                } label: {
                    Text("✋보")
                }

            }
            .font(.largeTitle)
        }
        .padding()
    }
    
    func showResult(selection userSelection: HandSelection) {
        
        let randomNumber: Int = Int.random(in: 0...2)
        var comSelection: HandSelection = .paper
        
        switch randomNumber {
        case 0:
            comSelection = .paper
        case 1:
            comSelection = .rock
        case 2:
            comSelection = .scissors
        default:
            comSelection = .paper
        }
        
        print("user: \(userSelection)")
        print("computer: \(comSelection)")
        
        if userSelection == comSelection {
            resultText = "비겼습니다"
        } else if userSelection == .paper && comSelection == .rock {
            resultText = "이겼습니다"
        } else if userSelection == .paper && comSelection == .scissors {
            resultText = "졌습니다"
        }
        // 여러분! 도와주세요!!
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
