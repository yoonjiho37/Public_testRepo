//
//  RockPaperScissorsApp.swift
//  RockPaperScissors
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

@main
struct RockPaperScissorsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
