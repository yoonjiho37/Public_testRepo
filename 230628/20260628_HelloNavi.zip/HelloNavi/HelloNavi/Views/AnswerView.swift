//
//  AnswerView.swift
//  HelloNavi
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

struct AnswerView: View {
    var body: some View {

        VStack {
            Text("앱스쿨 3기입니다")
                .padding()
            Text("우리가 누구인지 이제 아시겠어요?")
                .padding()
            
            NavigationLink {
                Text("우리는 멋사의 희망입니다!")
            } label: {
                Text("더 궁금하시면 여기를 누르세요")
                    .padding()
            }

            NavigationLink {
                Text("우리가 곧 멋사입니다!")
            } label: {
                Text("아직 궁금한게 더 남았나요?")
                    .padding()
            }
            
        }
        .navigationTitle("우리는 바로")

    }
}

struct AnswerView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            AnswerView()
        }
    }
}
