//
//  ContentView.swift
//  HelloNavi
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            
            VStack {
                NavigationLink {
                    // destination
                    AnswerView()
                    
                } label: {
                    Text("우리는 누구일까요?")
                        .padding()
                }
                
                
                Text("궁금하시면 위 버튼을 누르세요")
                    .padding()
            }
            .navigationTitle("궁금합니다")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
