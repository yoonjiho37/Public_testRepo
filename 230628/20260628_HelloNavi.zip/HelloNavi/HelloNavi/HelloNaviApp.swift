//
//  HelloNaviApp.swift
//  HelloNavi
//
//  Created by Jongwook Park on 2023/06/28.
//

import SwiftUI

@main
struct HelloNaviApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
