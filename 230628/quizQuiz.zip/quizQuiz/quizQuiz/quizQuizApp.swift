//
//  quizQuizApp.swift
//  quizQuiz
//
//  Created by 김윤우 on 2023/06/21.
//

import SwiftUI

@main
struct quizQuizApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
