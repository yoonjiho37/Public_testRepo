//
//  QuizQuizSwiftUIApp.swift
//  QuizQuizSwiftUI
//
//  Created by 최하늘 on 2023/06/21.
//

import SwiftUI

@main
struct QuizQuizSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
